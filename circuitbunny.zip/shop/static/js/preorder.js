//   $("#preorder").onsubmit = function (event) {
//         // Prevent the default form submission
//         event.preventDefault();

//         Swal.fire({
//             title: "Order Success",
//             text: "Your order has been added. We will contact with you soon... Thank you for your co-operation.",
//             icon: "success",
//         });
//     })